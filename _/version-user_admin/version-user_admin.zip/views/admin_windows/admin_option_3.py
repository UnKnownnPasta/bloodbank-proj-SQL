def abc():
    print(1)